function test() {
	alert('button clicked');
}